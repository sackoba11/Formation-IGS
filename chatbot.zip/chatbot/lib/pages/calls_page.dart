import 'package:flutter/material.dart';

class CallsPAge extends StatelessWidget {
  const CallsPAge({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(child: Text("No call history"));
  }
}
